#~ /bin/sh
sudo mkdir /var/run/screen && sudo chown kyehwanl.BGP-SRx /var/run/screen && sudo chmod 777 /var/run/screen
